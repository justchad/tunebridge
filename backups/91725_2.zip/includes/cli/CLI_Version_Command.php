<?php

namespace Tunebridge\CLI;

use WP_CLI;

/**
 * WP-CLI commands for managing TuneBridge versions.
 */
class CLI_Version_Command
{

	/**
	 * Show the current plugin version.
	 */
	public function get($args, $assoc_args)
	{
		$version = $this->get_version();
		WP_CLI::success('TuneBridge version: ' . $version);
	}

	/**
	 * Bump the version and write to Plugin.php.
	 *
	 * ## OPTIONS
	 *
	 * <type>
	 * : patch | minor | major
	 *
	 * ## EXAMPLES
	 *     wp tunebridge version bump patch
	 */
	public function bump($args, $assoc_args)
	{
		list($type) = $args;

		$plugin_file = __DIR__ . '/../core/Plugin.php';
		$current_version = $this->get_version();

		$parts = explode('.', $current_version);
		list($major, $minor, $patch) = array_map('intval', $parts);

		switch ($type) {
			case 'patch':
				$patch++;
				break;
			case 'minor':
				$minor++;
				$patch = 0;
				break;
			case 'major':
				$major++;
				$minor = $patch = 0;
				break;
			default:
				WP_CLI::error('Invalid bump type. Use patch, minor, or major.');
				return;
		}

		$new_version = "{$major}.{$minor}.{$patch}";

		$plugin_code = file_get_contents($plugin_file);
		$plugin_code = preg_replace_callback(
			"/(const VERSION = ')[0-9.]+(')/",
			function ($matches) use ($new_version) {
				return $matches[1] . $new_version . $matches[2];
			},
			$plugin_code
		);


		if (file_put_contents($plugin_file, $plugin_code) === false) {
			WP_CLI::error('Failed to write to Plugin.php');
		}

		WP_CLI::success("Plugin version bumped to {$new_version}");
	}

	/**
	 * Read current version from Plugin.php.
	 */
	private function get_version()
	{
		$plugin_file = __DIR__ . '/../core/Plugin.php';
		$plugin_code = file_get_contents($plugin_file);

		if (preg_match("/const VERSION = '([0-9.]+)'/", $plugin_code, $matches)) {
			return $matches[1];
		}

		WP_CLI::error('Could not read version from Plugin.php');
	}
}