<div class="card tunebridge-block">
    <div class="card-header">
        <h2 class="h4"><?php esc_html_e('Spotify Featured Playlists', 'tunebridge'); ?></h2>
    </div>
    <div class="card-body">
        <p><?php esc_html_e('Quick access to Spotify curated playlists.', 'tunebridge'); ?></p>
        <!-- TODO: Integrate Spotify Browse API -->
    </div>
</div>