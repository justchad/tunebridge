<div class="card tunebridge-block">
    <div class="card-header">
        <h2 class="h4"><?php esc_html_e('Notes', 'tunebridge'); ?></h2>
    </div>
    <div class="card-body">
        <p><?php esc_html_e('Autosaved notes will go here. Include tagging UI.', 'tunebridge'); ?></p>
        <!-- TODO: Add autosave + taggable UI -->
    </div>
</div>