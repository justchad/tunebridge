<?php

namespace Tunebridge\Admin\Pages;

defined('ABSPATH') || exit;

class Contacts_Page
{
    public static function render()
    {
        echo '<div class="wrap"><h1>Contacts (Coming Soon)</h1></div>';
    }
}