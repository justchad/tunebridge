<?php

namespace Tunebridge\Admin\Blocks;
/**
 * Blocks system placeholder for TuneBridge.
 *
 * @package TuneBridge
 */

namespace TuneBridge;

defined( 'ABSPATH' ) || exit;

class Blocks {
	// Reserved for future modular dashboard blocks.
}
