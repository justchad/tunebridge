<div class="card tunebridge-block">
    <div class="card-header">
        <h2 class="h4"><?php esc_html_e('Search Artists', 'tunebridge'); ?></h2>
    </div>
    <div class="card-body">
        <p><?php esc_html_e('Lookup artists to build contact cards from metadata sources.', 'tunebridge'); ?></p>
        <!-- TODO: Add artist search with Chartmetric / RocketReach -->
    </div>
</div>