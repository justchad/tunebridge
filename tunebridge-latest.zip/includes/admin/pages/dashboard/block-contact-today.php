<div class="card tunebridge-block">
    <div class="card-header">
        <h2 class="h4"><?php esc_html_e('Contact Today', 'tunebridge'); ?></h2>
    </div>
    <div class="card-body">
        <p><?php esc_html_e('This will show flagged contacts for today.', 'tunebridge'); ?></p>
        <!-- TODO: Load real data from contact model -->
    </div>
</div>