<?php

namespace Tunebridge\Admin\Pages;

defined('ABSPATH') || exit;

class Messaging_Page
{
    public static function render()
    {
        echo '<div class="wrap"><h1>Messaging (Coming Soon)</h1></div>';
    }
}